import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const Fees_table = () => {
  const [installments, setInstallments] = useState([]);
  const [courseFees, setCourseFees] = useState(0);
  const [discountRate, setDiscountRate] = useState("amount-");
  const [discountAmount, setDiscountAmount] = useState(0);
  const [totalFees, setTotalFees] = useState(0);
  const [feesReceived, setFeesReceived] = useState(0);

  const [feesBalance, setfeeBalance] = useState(0);
  const [remarks, setRemarks] = useState("");

  const navigate = useNavigate();
  // Calculate Total Fees
  const calculateTotalFees = () => {
    let updatedTotal = Number(courseFees) || 0; // Default to 0 if courseFees is empty or invalid
    console.log("without if ", discountAmount);
    if (discountRate === "amount-") {
      updatedTotal -= Number(discountAmount); // Subtract discount amount
      console.log(" with in if ", updatedTotal);
    } else if (discountRate === "amount+") {
      updatedTotal += Number(discountAmount); // Add discount amount
    } else if (discountRate === "percent-") {
      const percentage = updatedTotal * (Number(discountAmount) / 100); // Calculate percentage discount
      updatedTotal -= percentage;
    } else if (discountRate === "percent+") {
      const percentage = updatedTotal * (Number(discountAmount) / 100); // Calculate percentage increase
      updatedTotal += percentage;
    }
    setTotalFees(updatedTotal); // Update the state for Total Fees
  };

  // Handle Adding Installments
  const addInstallment = () => {
    setInstallments([...installments, { name: "", amount: 0, date: "" }]);
  };

  // // Handle Removing Installments
  const removeInstallment = (index) => {
    setInstallments(installments.filter((_, i) => i !== index));
  };

  // // Handle Installment Change
  const handleInstallmentChange = (index, field, value) => {
    const updatedInstallments = [...installments];
    updatedInstallments[index][field] = value;
    setInstallments(updatedInstallments);
  };

  useEffect(() => {
    calculateTotalFees();
  }, [discountAmount, discountRate]); // Recalculate whenever these dependencies change

  return (
    <div className="p-4 space-y-6">
      {/* Table for Fees  */}
      <div className="w-full  h-[120px] ">
        <table className="table-fixed w-full h-[100px] text-m">
          <thead>
            <tr className="bg-gray-200">
              <th className="border border-gray-300 px-2 py-2 w-[100px]">Course Fees</th>
              <th className="border border-gray-300 px-1 py-1 w-[80px]">Discount Rate</th>
              <th className="border border-gray-300 px-1 py-1 w-[100px]">Discount Amount</th>
              <th className="border border-gray-300 px-1 py-1 w-[100px]">Total Fees</th>
              <th className="border border-gray-300 px-1 py-1 w-[100px]">Fees Received</th>
              <th className="border border-gray-300 px-1 py-1 w-[100px]">Balance</th>
              <th className="border border-gray-300 px-1 py-1 w-[120px]">Remarks</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="border border-gray-300 py-2 px-2 text-center">
                <input
                  type="number"
                  className="border h-8 w-full rounded px-1 text-sm"
                  value={courseFees}
                  onChange={(e) => setCourseFees(e.target.value)}
                />
              </td>
              <td className="border border-gray-300 py-2 px-2 text-center">
                <select
                  className="w-full h-8 border rounded px-1 text-sm"
                  value={discountRate}
                  onChange={(e) => setDiscountRate(e.target.value)}
                >
                  <option value="amount+">Amount +</option>
                  <option value="amount-">Amount -</option>
                  <option value="percent+">Percent +</option>
                  <option value="percent-">Percent -</option>
                </select>
              </td>
              <td className="border border-gray-300 py-2 px-2 text-center">
                <input
                  type="number"
                  className="w-full h-8 border rounded px-1 text-sm"
                  value={discountAmount}
                  onChange={(e) => setDiscountAmount(Number(e.target.value))}
                />
              </td>
              <td className="border border-gray-300 py-2 px-2 text-center">
                <input
                  type="number"
                  className="w-full h-8 text-black border rounded px-1 text-sm bg-gray-300"
                  value={totalFees}
                  readOnly
                />
              </td>
              <td className="border border-gray-300 py-2 px-2 text-center">
                <input
                  type="number"
                  className="w-full h-8 border rounded px-1 text-sm"
                  value={feesReceived}
                  onChange={(e) => setFeesReceived(e.target.value)}
                />
              </td>
              <td className="border border-gray-300 py-2 px-2 text-center">
                <input
                  className="w-full h-8 border rounded px-1 text-sm"
                  value={feesBalance}
                  onChange={(e) => setfeeBalance(e.target.value)}
                />
              </td>
              <td className="border border-gray-300 py-2 px-2 text-center">
                <input
                  className="w-full h-8 border rounded px-1 text-sm"
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                />
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Installment Details */}
      <div>
        <h2 className="font-bold">Installment Details</h2>
        {installments.map((installment, index) => (
          <div className="grid grid-cols-5 gap-4 items-center mb-2" key={index}>
            <input
              type="text"
              placeholder="Installment Name"
              className="col-span-1 border rounded px-2 py-2"
              value={installment.name}
              onChange={(e) =>
                handleInstallmentChange(index, "name", e.target.value)
              }
            />
            <input
              type="number"
              placeholder="Amount"
              className="col-span-1 border rounded px-2 py-2"
              value={installment.amount}
              onChange={(e) =>
                handleInstallmentChange(index, "amount", e.target.value)
              }
            />
            <input
              type="date"
              className="col-span-1 border rounded px-2 py-2"
              value={installment.date}
              onChange={(e) =>
                handleInstallmentChange(index, "date", e.target.value)
              }
            />
            <button
              className="col-span-1 bg-red-500 text-white px-4 py-2 rounded"
              onClick={() => removeInstallment(index)}
            >
              Delete
            </button>
          </div>
        ))}
        <button
          className="bg-yellow-400 text-white px-4 py-2 rounded"
          onClick={addInstallment}
        >
          Add More
        </button>
      </div>

      {/* Batch Selection */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label>Select Batch for Student</label>
          <select className="w-full border rounded px-2 py-2">
            {/* Add options dynamically */}
            <option>1st Batch</option>
            <option>2nd Batch</option>
          </select>
        </div>
        <div >
          <label>Remaining Seats for this Batch</label>
          <input type="text" className="w-full rounded px-2 py-2" readOnly />
        </div>
      </div>

      {/* Admission Date */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label>Admission Date</label>
          <input type="date" className="w-full border rounded px-2 py-2" />
        </div>
        <div>
          <label>Display Admission Form/ID Card/Fees Receipt</label>
          <div className="flex gap-4 py-2">
            <label>
              <input type="radio" name="display" value="yes" /> Yes
            </label>
            <label>
              <input type="radio" name="display" value="no" /> No
            </label>
          </div>
        </div>
      </div>

      <button
        type="submit"
        className="bg-cyan-500 text-white px-4 py-2 rounded-2xl hover:bg-cyan-600"
      >
        Register Admission
      </button>
      <button
        className="bg-red-500 text-white ml-10 px-4 py-2 rounded-2xl hover:bg-red-600"
        onClick={() => navigate("/admission")}
      >
        Cancel
      </button>
    </div>
  );
};

export default Fees_table;
